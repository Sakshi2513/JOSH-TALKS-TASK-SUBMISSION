import pandas as pd
import re
from difflib import SequenceMatcher

print("="*60)
print("STEP 2: Building Lattice from Alignments")
print("="*60)

# Tokenized data
human = ['मौनता', 'का', 'अर्थ', 'क्या', 'होता', 'है']
models = {
    'K': ['मौन', 'तागार', 'थके', 'होतई'],
    'L': ['मोनता', 'का', 'अर्थ', 'है', 'क्या', 'होता', 'है'],
    'M': ['मोन', 'ताका', 'हर', 'थक्या', 'होताहए'],
    'N': ['मौनता', 'का', 'हर', 'थका', 'होता', 'है']
}

def similarity(a, b):
    """Calculate string similarity ratio"""
    return SequenceMatcher(None, a, b).ratio()

def align_to_human(human_seq, model_seq, model_name):
    """
    Align model sequence to human sequence
    Returns list of aligned words (None for gaps)
    """
    aligned = []
    h_idx = 0
    m_idx = 0
    
    while h_idx < len(human_seq) and m_idx < len(model_seq):
        human_word = human_seq[h_idx]
        model_word = model_seq[m_idx]
        
        # Check if they match or are similar
        if human_word == model_word or similarity(human_word, model_word) > 0.6:
            aligned.append(model_word)
            h_idx += 1
            m_idx += 1
        else:
            # Check if model word is similar to next human word
            if h_idx + 1 < len(human_seq):
                next_human = human_seq[h_idx + 1]
                if similarity(next_human, model_word) > 0.6:
                    # Insertion in human? Actually model skipped a word
                    aligned.append(None)  # Gap in alignment
                    h_idx += 1
                else:
                    # Substitution - different word
                    aligned.append(model_word)
                    h_idx += 1
                    m_idx += 1
            else:
                aligned.append(model_word)
                m_idx += 1
    
    # Fill remaining positions
    while h_idx < len(human_seq):
        aligned.append(None)
        h_idx += 1
    
    return aligned

print("Step 1: Aligning each model to human reference")
print("-"*60)

alignments = {}
for model_name, model_seq in models.items():
    aligned = align_to_human(human, model_seq, model_name)
    alignments[model_name] = aligned
    print(f"\nModel {model_name}:")
    print(f"  Original: {model_seq}")
    print(f"  Aligned:  {aligned}")

print("\n" + "="*60)
print("Step 2: Building Lattice Bins")
print("="*60)

# Create bins for each human word position
lattice = []
for pos, human_word in enumerate(human):
    bin_words = [human_word]  # Start with human word
    
    # Add words from models at this position
    for model_name, aligned in alignments.items():
        if pos < len(aligned) and aligned[pos] is not None:
            if aligned[pos] not in bin_words:
                bin_words.append(aligned[pos])
    
    lattice.append({
        'position': pos + 1,
        'human_word': human_word,
        'alternatives': bin_words,
        'count': len(bin_words)
    })

print("\nLATTICE STRUCTURE:")
print("-"*60)
for bin_item in lattice:
    print(f"Bin {bin_item['position']}: '{bin_item['human_word']}'")
    print(f"  Alternatives: {bin_item['alternatives']}")
    print(f"  Total variants: {bin_item['count']}")
    print()

print("="*60)
print("Step 3: Lattice Visualization")
print("="*60)

# Simple visual
print("\nPath through lattice:")
print("-"*60)
path = []
for bin_item in lattice:
    path.append(f"[{'|'.join(bin_item['alternatives'])}]")
print(" → ".join(path))

print("\n✅ Lattice built successfully!")
print(f"Total bins: {len(lattice)}")
print(f"Total alternative words captured: {sum(b['count'] for b in lattice)}")