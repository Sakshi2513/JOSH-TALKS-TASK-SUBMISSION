import pandas as pd
import re
from difflib import SequenceMatcher

print("="*60)
print("STEP 3: Computing WER Using Lattice")
print("="*60)

# Our lattice from previous step
lattice = [
    {'position': 1, 'human_word': 'मौनता', 'alternatives': ['मौनता', 'मौन', 'मोनता', 'मोन']},
    {'position': 2, 'human_word': 'का', 'alternatives': ['का', 'तागार', 'ताका']},
    {'position': 3, 'human_word': 'अर्थ', 'alternatives': ['अर्थ', 'थके', 'हर']},
    {'position': 4, 'human_word': 'क्या', 'alternatives': ['क्या', 'है', 'थक्या', 'थका']},
    {'position': 5, 'human_word': 'होता', 'alternatives': ['होता', 'होतई', 'क्या', 'होताहए']},
    {'position': 6, 'human_word': 'है', 'alternatives': ['है', 'होता']}
]

# Model outputs
models_output = {
    'Human': ['मौनता', 'का', 'अर्थ', 'क्या', 'होता', 'है'],
    'Model H': ['मौनता', 'का', 'अर्थ', 'क्या', 'होता', 'है'],
    'Model I': ['मौनता', 'का', 'अर्थ', 'क्या', 'होता', 'है'],
    'Model K': ['मौन', 'तागार', 'थके', 'होतई'],
    'Model L': ['मोनता', 'का', 'अर्थ', 'है', 'क्या', 'होता', 'है'],
    'Model M': ['मोन', 'ताका', 'हर', 'थक्या', 'होताहए'],
    'Model N': ['मौनता', 'का', 'हर', 'थका', 'होता', 'है']
}

def compute_lattice_wer(model_tokens, lattice):
    """
    Compute WER using lattice bins
    Model gets credit if word matches ANY alternative in the bin
    """
    errors = 0
    total = len(lattice)
    
    # Align model to lattice bins
    m_idx = 0
    
    for bin_idx, bin_item in enumerate(lattice):
        alternatives = bin_item['alternatives']
        
        # Find if model has a word at this position
        if m_idx < len(model_tokens):
            model_word = model_tokens[m_idx]
            
            # Check if model word is valid for this bin
            if model_word in alternatives:
                # Correct! Move to next bin and next model word
                m_idx += 1
            else:
                # Error: substitution or insertion
                errors += 1
                # Check if this model word might belong to next bin
                found_next = False
                if bin_idx + 1 < len(lattice):
                    next_alternatives = lattice[bin_idx + 1]['alternatives']
                    if model_word in next_alternatives:
                        # It belongs to next bin, don't consume it yet
                        found_next = True
                
                if not found_next:
                    # Word is error, consume it
                    m_idx += 1
        else:
            # Model has fewer words - deletion error
            errors += 1
    
    # If model has extra words at the end
    while m_idx < len(model_tokens):
        errors += 1
        m_idx += 1
    
    wer = errors / total
    return wer, errors, total

def compute_traditional_wer(reference, hypothesis):
    """Traditional WER for comparison"""
    # Simple word-by-word comparison
    ref_words = reference
    hyp_words = hypothesis
    
    errors = 0
    for i in range(min(len(ref_words), len(hyp_words))):
        if ref_words[i] != hyp_words[i]:
            errors += 1
    
    errors += abs(len(ref_words) - len(hyp_words))
    return errors / len(ref_words)

print("Computing WER for each model:")
print("-"*70)
print(f"{'Model':<12} {'Traditional WER':<18} {'Lattice WER':<15} {'Improvement':<12}")
print("-"*70)

results = []

for model_name, model_tokens in models_output.items():
    # Traditional WER (against human reference)
    human_tokens = models_output['Human']
    traditional_wer = compute_traditional_wer(human_tokens, model_tokens)
    
    # Lattice WER
    lattice_wer, errors, total = compute_lattice_wer(model_tokens, lattice)
    
    improvement = traditional_wer - lattice_wer
    
    results.append({
        'model': model_name,
        'traditional_wer': traditional_wer,
        'lattice_wer': lattice_wer,
        'improvement': improvement,
        'errors': errors,
        'total': total
    })
    
    status = "✅" if improvement > 0 else "➖"
    print(f"{model_name:<12} {traditional_wer:.2%}           {lattice_wer:.2%}            {status} {improvement:+.2%}")

print("-"*70)

print("\n" + "="*60)
print("DETAILED ANALYSIS")
print("="*60)

for r in results:
    if r['improvement'] > 0:
        print(f"\n✅ {r['model']}: Improved by {r['improvement']:.2%}")
        print(f"   Traditional WER: {r['traditional_wer']:.2%}")
        print(f"   Lattice WER:     {r['lattice_wer']:.2%}")
        print(f"   Why: Model's words matched valid alternatives in lattice")

print("\n" + "="*60)
print("LATTICE BENEFITS SUMMARY")
print("="*60)
print("Models that improved:")
for r in results:
    if r['improvement'] > 0:
        print(f"  - {r['model']}: {r['improvement']:+.2%}")

print("\nModels unchanged (already perfect):")
for r in results:
    if r['improvement'] == 0:
        print(f"  - {r['model']}: {r['traditional_wer']:.2%}")

print("\n✅ Lattice-based evaluation reduces unfair penalization!")