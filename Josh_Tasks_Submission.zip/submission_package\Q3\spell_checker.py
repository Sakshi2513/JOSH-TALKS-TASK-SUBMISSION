import pandas as pd
import re
from collections import Counter
import string

print("="*60)
print("STEP 2: Building Hindi Spell Checker")
print("="*60)

# Load unique words
words_df = pd.read_csv('unique_words.csv')
words = words_df['word'].tolist()
print(f"Loaded {len(words)} unique words")

class HindiSpellChecker:
    def __init__(self):
        # Common Hindi words (from your first 20 list)
        self.common_words = {
            'है', 'तो', 'में', 'जी', 'हैं', 'भी', 'के', 'नहीं', 'कि', 'वो',
            'और', 'से', 'जो', 'हो', 'मतलब', 'हां', 'हम', 'की', 'है', 'था',
            'थी', 'थे', 'गया', 'गई', 'गए', 'रहा', 'रही', 'रहे', 'कर', 'किया',
            'की', 'का', 'के', 'ने', 'को', 'से', 'पर', 'में', 'ही', 'भी'
        }
        
        # Valid Hindi vowel patterns
        self.valid_vowel_patterns = [
            r'[अ-औ]',  # Vowels
            r'[क-ह]',   # Consonants
            r'[़]',      # Nukta
            r'[्]',      # Virama
            r'[ा-ौ]'    # Matras
        ]
        
        # Common spelling error patterns
        self.error_patterns = {
            'ँ': ['ं'],      # Chandrabindu often confused with bindu
            'ं': ['ँ'],      # Bindu confused with chandrabindu
            'औ': ['ओ', 'अउ'],  # Confusion with ओ
            'ओ': ['औ'],
            'ए': ['ऐ', 'इ'],
            'ऐ': ['ए'],
            'श': ['ष', 'स'],   # Similar sounds
            'ष': ['श', 'स'],
            'स': ['श', 'ष'],
            'ज': ['ज़'],        # Persian influence
            'ज़': ['ज'],
            'फ': ['फ़'],
            'फ़': ['फ'],
        }
        
        # Loanwords (English words in Devanagari) - these are correct
        self.loanwords = {
            'प्रोजेक्ट', 'इंटरव्यू', 'जॉब', 'क्रिकेट', 'कंप्यूटर',
            'मोबाइल', 'फोन', 'लैपटॉप', 'ऑफिस', 'स्कूल', 'कॉलेज'
        }
    
    def is_valid_hindi_char(self, char):
        """Check if character is valid Hindi character"""
        for pattern in self.valid_vowel_patterns:
            if re.match(pattern, char):
                return True
        return False
    
    def has_valid_structure(self, word):
        """Check if word follows Hindi structure rules"""
        # Words should have at least one vowel or matra
        has_vowel = bool(re.search(r'[अ-औ]', word))
        has_matra = bool(re.search(r'[ा-ौ]', word))
        
        # Very short words can be exceptions
        if len(word) <= 2:
            return True
        
        return has_vowel or has_matra
    
    def is_common_word(self, word):
        """Check if word is in common Hindi vocabulary"""
        return word in self.common_words
    
    def is_loanword(self, word):
        """Check if word is a valid English loanword in Devanagari"""
        return word in self.loanwords
    
    def detect_character_repetition(self, word):
        """Detect repeated characters (spelling mistakes)"""
        for i in range(len(word) - 2):
            if word[i] == word[i+1] == word[i+2]:
                return True
        return False
    
    def has_unusual_consonant_cluster(self, word):
        """Detect unusual consonant clusters"""
        # Count consecutive consonants without vowels/matras
        consonant_count = 0
        max_consonants = 0
        
        for char in word:
            if char in 'कखगघङचछजझञटठडढणतथदधनपफबभमयरलवशषसह':
                consonant_count += 1
                max_consonants = max(max_consonants, consonant_count)
            else:
                consonant_count = 0
        
        return max_consonants > 3  # More than 3 consonants in a row is suspicious
    
    def check_spelling(self, word):
        """Main spell checking function with confidence score"""
        confidence = "high"
        reasons = []
        is_correct = True
        
        # Rule 1: Common words are correct
        if self.is_common_word(word):
            reasons.append("Common Hindi word")
            return is_correct, confidence, reasons
        
        # Rule 2: Loanwords are correct
        if self.is_loanword(word):
            reasons.append("Valid English loanword in Devanagari")
            return is_correct, confidence, reasons
        
        # Rule 3: Check for repeated characters
        if self.detect_character_repetition(word):
            is_correct = False
            confidence = "high"
            reasons.append("Repeated characters (likely typo)")
            return is_correct, confidence, reasons
        
        # Rule 4: Check structure
        if not self.has_valid_structure(word):
            is_correct = False
            confidence = "high"
            reasons.append("Invalid Hindi structure (no vowels)")
            return is_correct, confidence, reasons
        
        # Rule 5: Check consonant clusters
        if self.has_unusual_consonant_cluster(word):
            is_correct = False
            confidence = "medium"
            reasons.append("Unusual consonant cluster")
            return is_correct, confidence, reasons
        
        # Rule 6: Check length
        if len(word) > 15:
            confidence = "low"
            reasons.append("Very long word - possible concatenation error")
            # Still might be correct, just low confidence
        
        # Default: Probably correct
        if is_correct:
            reasons.append("Valid Hindi word pattern")
        
        return is_correct, confidence, reasons

# Initialize checker
checker = HindiSpellChecker()

# Test on sample words
print("\n📝 Testing Spell Checker on Sample Words:")
print("-"*60)

test_words = [
    'है', 'में', 'मतलब',  # Correct common words
    'हाँ', 'हां',          # Valid variations
    'प्रोजेक्ट',          # Loanword
    'उखाड़', 'लगड़ा',      # Valid words
    'बोहोत',              # Possible typo for बहुत
    'अदददद',              # Repetition error
    'क्श',                # Invalid structure
]

for word in test_words:
    is_correct, confidence, reasons = checker.check_spelling(word)
    status = "✅" if is_correct else "❌"
    print(f"{status} '{word}' → {is_correct} (Confidence: {confidence})")
    print(f"   Reasons: {', '.join(reasons)}")
    print()

# Now check all unique words
print("="*60)
print("Checking all unique words...")
print("="*60)

results = []
correct_count = 0
incorrect_count = 0

for word in words:
    is_correct, confidence, reasons = checker.check_spelling(word)
    results.append({
        'word': word,
        'classification': 'correct' if is_correct else 'incorrect',
        'confidence': confidence,
        'reason': ', '.join(reasons)
    })
    
    if is_correct:
        correct_count += 1
    else:
        incorrect_count += 1

# Create DataFrame
results_df = pd.DataFrame(results)

# Save results
results_df.to_csv('spell_check_results.csv', index=False)

print(f"\n✅ Results saved to spell_check_results.csv")
print(f"\n📊 Summary:")
print(f"   Total unique words: {len(words)}")
print(f"   Correctly spelled: {correct_count}")
print(f"   Incorrectly spelled: {incorrect_count}")

# Confidence distribution
print(f"\n📊 Confidence Distribution:")
conf_dist = results_df['confidence'].value_counts()
for conf, count in conf_dist.items():
    print(f"   {conf}: {count} words")

# Show sample of incorrect words
print(f"\n📝 Sample of incorrectly spelled words (first 20):")
incorrect_words = results_df[results_df['classification'] == 'incorrect']
for idx, row in incorrect_words.head(20).iterrows():
    print(f"   {row['word']} (Confidence: {row['confidence']}) - {row['reason']}")

print(f"\n✅ Part A Complete: Found {correct_count} correctly spelled words")