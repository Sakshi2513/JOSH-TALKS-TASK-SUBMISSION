import torch
import pandas as pd
import librosa
import requests
import io
from transformers import WhisperProcessor, WhisperForConditionalGeneration
from torch.optim import AdamW
from datasets import Dataset
from tqdm import tqdm
import warnings
warnings.filterwarnings('ignore')

# Check if GPU available
device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Using device: {device}")

# Load data
df = pd.read_csv('processed_data/train_data.csv')
print(f"Loaded {len(df)} training samples")

# Load model and processor
model_name = "openai/whisper-small"
processor = WhisperProcessor.from_pretrained(model_name, language="hindi", task="transcribe")
model = WhisperForConditionalGeneration.from_pretrained(model_name).to(device)

# Function to download audio from URL
def download_audio(url):
    try:
        response = requests.get(url, timeout=30)
        if response.status_code == 200:
            audio_bytes = io.BytesIO(response.content)
            audio_array, sr = librosa.load(audio_bytes, sr=16000)
            return audio_array, sr
        else:
            return None, None
    except Exception as e:
        print(f"Download error: {e}")
        return None, None

# Process each sample
print("Processing audio files...")
processed_data = []

for idx, row in tqdm(df.iterrows(), total=len(df), desc="Loading audio"):
    # Download audio
    audio_array, sr = download_audio(row['audio_url'])
    
    if audio_array is not None:
        # Process with Whisper
        input_features = processor(audio_array, sampling_rate=16000, return_tensors="pt").input_features
        
        # Tokenize transcript
        labels = processor.tokenizer(row['transcript'], truncation=True, max_length=448, return_tensors="pt").input_ids
        
        processed_data.append({
            'input_features': input_features[0],
            'labels': labels[0],
            'transcript': row['transcript']
        })

print(f"\n✅ Successfully loaded {len(processed_data)} audio files")

if len(processed_data) == 0:
    print("❌ No audio files loaded. Check URLs.")
    exit()

# Convert to dataset
train_dataset = Dataset.from_list(processed_data)
train_dataset = train_dataset.with_format("torch")

# Create data loader with padding
from torch.utils.data import DataLoader
from transformers import DataCollatorForSeq2Seq

# Use built-in collator
data_collator = DataCollatorForSeq2Seq(
    tokenizer=processor.tokenizer,
    model=model,
    padding=True
)

def collate_fn(batch):
    # Stack input features
    input_features = torch.stack([item['input_features'] for item in batch])
    
    # Prepare labels for collator
    labels_list = [{'input_ids': item['labels']} for item in batch]
    labels_batch = processor.tokenizer.pad(labels_list, return_tensors="pt", padding=True)
    labels = labels_batch['input_ids']
    
    # Replace padding token id with -100 for loss calculation
    labels[labels == processor.tokenizer.pad_token_id] = -100
    
    return {'input_features': input_features, 'labels': labels}

train_loader = DataLoader(train_dataset, batch_size=4, shuffle=True, collate_fn=collate_fn)

# Optimizer
optimizer = AdamW(model.parameters(), lr=1e-5)

# Training
model.train()
print("\n🚀 Starting training...")

for epoch in range(3):
    total_loss = 0
    progress_bar = tqdm(train_loader, desc=f"Epoch {epoch+1}/3")
    
    for batch in progress_bar:
        # Move to device
        input_features = batch['input_features'].to(device)
        labels = batch['labels'].to(device)
        
        # Forward pass
        outputs = model(input_features=input_features, labels=labels)
        loss = outputs.loss
        
        # Backward
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        total_loss += loss.item()
        progress_bar.set_postfix({'loss': f'{loss.item():.4f}'})
    
    avg_loss = total_loss / len(train_loader)
    print(f"Epoch {epoch+1} - Avg Loss: {avg_loss:.4f}")

# Save model
model.save_pretrained("./whisper-hindi-finetuned")
processor.save_pretrained("./whisper-hindi-finetuned")
print("\n✅ Model saved to ./whisper-hindi-finetuned")