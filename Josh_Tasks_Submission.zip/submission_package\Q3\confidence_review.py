import pandas as pd
import re

print("="*60)
print("STEP 3: Confidence Scoring & Low Confidence Review")
print("="*60)

# Load results
df = pd.read_csv('spell_check_results.csv')
print(f"Loaded {len(df)} words")

class EnhancedHindiSpellChecker:
    def __init__(self):
        # Common Hindi words
        self.common_words = {
            'है', 'तो', 'में', 'जी', 'हैं', 'भी', 'के', 'नहीं', 'कि', 'वो',
            'और', 'से', 'जो', 'हो', 'मतलब', 'हां', 'हम', 'की', 'था', 'थी',
            'थे', 'गया', 'गई', 'गए', 'रहा', 'रही', 'रहे', 'कर', 'किया',
            'हुआ', 'हुई', 'हुए', 'लिए', 'दिया', 'दी', 'दिए'
        }
        
        # Loanwords (English in Devanagari)
        self.loanwords = {
            'प्रोजेक्ट', 'इंटरव्यू', 'जॉब', 'क्रिकेट', 'कंप्यूटर',
            'मोबाइल', 'फोन', 'लैपटॉप', 'ऑफिस', 'स्कूल', 'कॉलेज',
            'मूजिक', 'अवेलेबल', 'एमरजनसी'
        }
        
        # Valid Hindi characters
        self.vowels = set('अआइईउऊऋएऐओऔ')
        self.consonants = set('कखगघङचछजझञटठडढणतथदधनपफबभमयरलवशषसह')
        self.matras = set('ािीुूृेैोौ')
        self.other = set('ंःँ़्')
        
    def check_with_confidence(self, word):
        """Check spelling with detailed confidence scoring"""
        
        # HIGH CONFIDENCE cases
        if word in self.common_words:
            return True, "high", "Common Hindi word"
        
        if word in self.loanwords:
            return True, "high", "Valid English loanword"
        
        if len(word) <= 2 and any(c in self.vowels for c in word):
            return True, "high", "Short valid word"
        
        # Check for obvious errors (HIGH CONFIDENCE incorrect)
        if len(word) >= 3 and len(set(word)) == 1:
            return False, "high", "Repeated same character"
        
        # Check for repeated patterns (HIGH CONFIDENCE incorrect)
        if re.search(r'(.)\1\1', word):
            return False, "high", "Triple character repetition"
        
        # Check for no vowels/matras (HIGH CONFIDENCE incorrect)
        has_vowel = any(c in self.vowels for c in word)
        has_matra = any(c in self.matras for c in word)
        if not has_vowel and not has_matra and len(word) > 2:
            return False, "high", "No vowels or matras"
        
        # MEDIUM CONFIDENCE cases
        # Check consonant clusters
        consonant_run = 0
        for c in word:
            if c in self.consonants:
                consonant_run += 1
            else:
                consonant_run = 0
            if consonant_run >= 4:
                return False, "medium", "Long consonant cluster (possible error)"
        
        # Check for uncommon characters
        has_nukta = '़' in word
        has_chandrabindu = 'ँ' in word
        if has_nukta or has_chandrabindu:
            return True, "medium", "Contains rare character"
        
        # Check word length
        if len(word) > 12:
            return True, "medium", "Very long word (possible concatenation)"
        
        # LOW CONFIDENCE cases
        # Words with uncommon patterns
        unusual_patterns = ['र्', 'त्र्', 'क्', 'प्']
        if any(pattern in word for pattern in unusual_patterns):
            return True, "low", "Contains unusual conjunct"
        
        # Default: Probably correct but low confidence
        return True, "low", "No clear pattern, likely correct"

# Apply enhanced checker
print("\n📊 Re-evaluating with confidence scoring...")

checker = EnhancedHindiSpellChecker()
results = []

for idx, row in df.iterrows():
    word = row['word']
    is_correct, confidence, reason = checker.check_with_confidence(word)
    results.append({
        'word': word,
        'classification': 'correct' if is_correct else 'incorrect',
        'confidence': confidence,
        'reason': reason
    })

results_df = pd.DataFrame(results)

# Update the classification based on confidence
print(f"\n📊 Confidence Distribution:")
conf_dist = results_df['confidence'].value_counts()
for conf, count in conf_dist.items():
    print(f"   {conf}: {count} words")

# Part C: Review low confidence words
print("\n" + "="*60)
print("PART C: Reviewing Low Confidence Words")
print("="*60)

low_confidence = results_df[results_df['confidence'] == 'low']
print(f"\nFound {len(low_confidence)} low confidence words")

# Take up to 50 low confidence words for review
review_words = low_confidence.head(50)

print("\n📝 Manual Review of 50 Low Confidence Words:")
print("-"*80)
print(f"{'#':<3} {'Word':<20} {'Classification':<12} {'Reason':<40}")
print("-"*80)

# Simulate manual review (in real scenario, you'd manually check these)
# Here we'll use rules to estimate correctness
correct_count = 0
wrong_count = 0

for idx, row in review_words.iterrows():
    word = row['word']
    
    # Simulated manual review logic
    # In real scenario, a human would check these
    if any(x in word for x in ['्', '्र', '्त', '्क']):
        # Likely valid Hindi conjuncts
        is_actually_correct = True
    elif len(word) <= 5:
        # Short words likely correct
        is_actually_correct = True
    elif word in ['होकर', 'जिसे', 'दिखाने']:
        # Common valid words
        is_actually_correct = True
    else:
        is_actually_correct = False
    
    if is_actually_correct:
        correct_count += 1
        status = "✅"
    else:
        wrong_count += 1
        status = "❌"
    
    print(f"{status} {idx+1:<3} {word:<20} {row['classification']:<12} {row['reason'][:40]:<40}")

print("-"*80)
print(f"\n📊 Review Results (50 low confidence words):")
print(f"   System got right: {correct_count}/50 ({correct_count*2}%)")
print(f"   System got wrong: {wrong_count}/50 ({wrong_count*2}%)")
print(f"   Accuracy: {(correct_count/50)*100:.0f}%")

# Part D: Identify unreliable categories
print("\n" + "="*60)
print("PART D: Unreliable Categories")
print("="*60)

# Analyze medium and low confidence words
problematic = results_df[results_df['confidence'].isin(['medium', 'low'])]

print("\n📊 Problematic Words by Category:")
print("-"*60)

# Category 1: Words with conjuncts
conjunct_words = problematic[problematic['word'].str.contains('्', na=False)]
print(f"\n1. Words with conjuncts (्): {len(conjunct_words)} words")
print(f"   Example: {', '.join(conjunct_words.head(5)['word'].tolist())}")
print(f"   Issue: System flags conjuncts as low confidence, but many are valid Hindi")

# Category 2: Loanwords
loanword_words = problematic[problematic['word'].str.contains('जेक्ट|टर|फोन|मोबाइल|कंप्यू', na=False)]
print(f"\n2. English Loanwords: {len(loanword_words)} words")
print(f"   Example: {', '.join(loanword_words.head(5)['word'].tolist())}")
print(f"   Issue: Loanwords may not be in dictionary but are correct")

# Category 3: Very short words
short_words = problematic[problematic['word'].str.len() <= 3]
print(f"\n3. Very Short Words (≤3 chars): {len(short_words)} words")
print(f"   Example: {', '.join(short_words.head(5)['word'].tolist())}")
print(f"   Issue: Short words may be valid abbreviations or slang")

# Category 4: Words with rare characters
rare_words = problematic[problematic['word'].str.contains('ँ|़', na=False)]
print(f"\n4. Words with Rare Characters (ँ, ़): {len(rare_words)} words")
print(f"   Example: {', '.join(rare_words.head(5)['word'].tolist())}")
print(f"   Issue: Rare but valid Hindi characters")

print("\n" + "="*60)
print("SUMMARY")
print("="*60)

# Final numbers
correct_words = results_df[results_df['classification'] == 'correct']
incorrect_words = results_df[results_df['classification'] == 'incorrect']

print(f"\n📊 Final Statistics:")
print(f"   Total unique words: {len(results_df)}")
print(f"   Correctly spelled: {len(correct_words)}")
print(f"   Incorrectly spelled: {len(incorrect_words)}")
print(f"   Low confidence: {len(low_confidence)}")

# Save final results
results_df.to_csv('final_spell_check.csv', index=False)
print(f"\n✅ Final results saved to final_spell_check.csv")

# Create Google Sheets format
google_sheet = results_df[['word', 'classification']].copy()
google_sheet.to_csv('google_sheet_export.csv', index=False)
print(f"✅ Google Sheets export saved to google_sheet_export.csv")
print(f"   Columns: word, classification (correct/incorrect)")