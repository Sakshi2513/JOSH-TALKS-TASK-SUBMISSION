import torch
import pandas as pd
import librosa
import requests
import io
from transformers import WhisperProcessor, WhisperForConditionalGeneration
import jiwer
from tqdm import tqdm
import warnings
warnings.filterwarnings('ignore')

print("Loading models...")

# Load fine-tuned model
ft_processor = WhisperProcessor.from_pretrained("./whisper-hindi-finetuned")
ft_model = WhisperForConditionalGeneration.from_pretrained("./whisper-hindi-finetuned")

# Load baseline
base_processor = WhisperProcessor.from_pretrained("openai/whisper-small", language="hindi", task="transcribe")
base_model = WhisperForConditionalGeneration.from_pretrained("openai/whisper-small")

# Load data
df = pd.read_csv('processed_data/train_data.csv')
test_df = df.sample(min(30, len(df)), random_state=42)
print(f"\nTesting on {len(test_df)} samples...")

# Function to download audio
def download_audio(url):
    try:
        response = requests.get(url, timeout=30)
        if response.status_code == 200:
            audio_bytes = io.BytesIO(response.content)
            audio_array, sr = librosa.load(audio_bytes, sr=16000)
            return audio_array
        return None
    except:
        return None

# Function to transcribe
def transcribe(audio, processor, model):
    input_features = processor(audio, sampling_rate=16000, return_tensors="pt").input_features
    predicted_ids = model.generate(input_features)
    transcription = processor.batch_decode(predicted_ids, skip_special_tokens=True)[0]
    return transcription

# Test each sample
results = []
errors = []

for idx, row in tqdm(test_df.iterrows(), total=len(test_df), desc="Evaluating"):
    audio = download_audio(row['audio_url'])
    
    if audio is not None:
        # Baseline prediction
        base_text = transcribe(audio, base_processor, base_model)
        
        # Fine-tuned prediction
        ft_text = transcribe(audio, ft_processor, ft_model)
        
        results.append({
            'recording_id': row['recording_id'],
            'reference': row['transcript'],
            'baseline': base_text,
            'finetuned': ft_text
        })
        
        # Collect errors for analysis
        if ft_text != row['transcript']:
            errors.append({
                'reference': row['transcript'],
                'prediction': ft_text,
                'recording_id': row['recording_id']
            })

# Calculate WER
if results:
    refs = [r['reference'] for r in results]
    base_preds = [r['baseline'] for r in results]
    ft_preds = [r['finetuned'] for r in results]
    
    base_wer = jiwer.wer(refs, base_preds)
    ft_wer = jiwer.wer(refs, ft_preds)
    
    print("\n" + "="*70)
    print("WORD ERROR RATE RESULTS")
    print("="*70)
    print(f"Baseline Whisper-small:      {base_wer:.2%}")
    print(f"Fine-tuned Whisper-small:    {ft_wer:.2%}")
    print(f"Improvement:                 {(base_wer - ft_wer):.2%}")
    print("="*70)
    
    # Save results
    results_df = pd.DataFrame(results)
    results_df.to_csv("evaluation_results.csv", index=False)
    print("\n✅ Results saved to evaluation_results.csv")
    
    # Save errors for analysis
    if errors:
        errors_df = pd.DataFrame(errors)
        errors_df.to_csv("error_samples.csv", index=False)
        print(f"✅ Saved {len(errors)} error samples to error_samples.csv")
        
        # Show first 5 errors
        print("\n📝 Sample Errors (first 5):")
        for i in range(min(5, len(errors))):
            print(f"\n--- Error {i+1} ---")
            print(f"Reference:  {errors[i]['reference'][:150]}...")
            print(f"Prediction: {errors[i]['prediction'][:150]}...")
    else:
        print("\n✅ No errors found!")
else:
    print("❌ No audio files could be downloaded")