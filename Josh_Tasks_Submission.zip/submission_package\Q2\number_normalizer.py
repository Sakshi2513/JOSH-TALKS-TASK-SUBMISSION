import pandas as pd
import re

print("="*60)
print("STEP 6: Final Number Conversion - Fixed Multipliers")
print("="*60)

class NumberNormalizer:
    def __init__(self):
        # Single digits
        self.digits = {
            'एक': 1, 'दो': 2, 'तीन': 3, 'चार': 4,
            'पाँच': 5, 'पांच': 5, 'छह': 6, 'छः': 6,
            'सात': 7, 'आठ': 8, 'नौ': 9, 'शून्य': 0
        }
        
        # Tens
        self.tens = {
            'दस': 10, 'ग्यारह': 11, 'बारह': 12, 'तेरह': 13,
            'चौदह': 14, 'पंद्रह': 15, 'सोलह': 16, 'सत्रह': 17,
            'अठारह': 18, 'उन्नीस': 19, 'बीस': 20, 'तीस': 30,
            'चालीस': 40, 'पचास': 50, 'साठ': 60, 'सत्तर': 70,
            'अस्सी': 80, 'नब्बे': 90
        }
        
        # Compound tens (21-29, 31-39, etc.)
        self.compound_tens = {
            'इक्कीस': 21, 'बाईस': 22, 'तेईस': 23, 'चौबीस': 24,
            'पच्चीस': 25, 'छब्बीस': 26, 'सत्ताईस': 27, 'अट्ठाईस': 28,
            'उनतीस': 29, 'इकतीस': 31, 'बत्तीस': 32, 'तैंतीस': 33,
            'चौंतीस': 34, 'पैंतीस': 35, 'छत्तीस': 36, 'सैंतीस': 37,
            'अड़तीस': 38, 'उनतालीस': 39,
            'इक्यावन': 51, 'बावन': 52, 'तिरेपन': 53, 'चौवन': 54,
            'पचपन': 55, 'छप्पन': 56, 'सत्तावन': 57, 'अट्ठावन': 58, 'उनसठ': 59,
            'इकसठ': 61, 'बासठ': 62, 'तिरेसठ': 63, 'चौंसठ': 64,
            'पैंसठ': 65, 'छियासठ': 66, 'सड़सठ': 67, 'अड़सठ': 68, 'उनहत्तर': 69,
            'इकहत्तर': 71, 'बहत्तर': 72, 'तिहत्तर': 73, 'चौहत्तर': 74,
            'पचहत्तर': 75, 'छिहत्तर': 76, 'सतहत्तर': 77, 'अठहत्तर': 78, 'उन्यासी': 79,
            'इक्यासी': 81, 'बयासी': 82, 'तिरासी': 83, 'चौरासी': 84,
            'पचासी': 85, 'छियासी': 86, 'सतासी': 87, 'अठासी': 88, 'नवासी': 89,
            'इक्यानवे': 91, 'बानवे': 92, 'तिरानवे': 93, 'चौरानवे': 94,
            'पचानवे': 95, 'छियानवे': 96, 'सत्तानवे': 97, 'अट्ठानवे': 98, 'निन्यानवे': 99
        }
        
        # Multipliers
        self.multipliers = {
            'करोड़': 10000000,
            'लाख': 100000,
            'हज़ार': 1000,
            'सौ': 100
        }
        
        # Idioms
        self.idioms = [
            'दो-चार', 'दो-एक', 'चार-पाँच', 'एक-दो', 'तीन-चार',
            'दो-बात', 'सौ-पचास', 'अठारह-बीस', 'दो-दो', 'चार-चार'
        ]
        
        # Combine all number words
        self.number_words = {**self.digits, **self.tens, **self.compound_tens}
    
    def is_idiomatic(self, text):
        for idiom in self.idioms:
            if idiom in text:
                return True
        return False
    
    def convert_complex_number(self, words):
        """Convert 'तीन सौ चौवन' → 354, 'दस लाख' → 10000000"""
        total = 0
        current = 0
        i = 0
        
        while i < len(words):
            word = words[i]
            
            # If it's a number word
            if word in self.number_words:
                current = self.number_words[word]
                i += 1
                
                # Check if next word is a multiplier
                if i < len(words) and words[i] in self.multipliers:
                    multiplier = self.multipliers[words[i]]
                    total += current * multiplier
                    current = 0
                    i += 1
                # If no multiplier after, add to total later
                elif current > 0:
                    # If we have a number without multiplier, check next numbers
                    # For now, accumulate and handle at the end
                    pass
            # If it's a multiplier with no preceding number
            elif word in self.multipliers:
                multiplier = self.multipliers[word]
                if current == 0:
                    current = 1
                total += current * multiplier
                current = 0
                i += 1
            else:
                return None
        
        total += current
        return str(total) if total > 0 else None
    
    def normalize(self, text):
        """Main normalization function"""
        if self.is_idiomatic(text):
            return text
        
        words = text.split()
        
        # Single number word
        if len(words) == 1 and words[0] in self.number_words:
            return str(self.number_words[words[0]])
        
        # Complex number phrase
        complex_result = self.convert_complex_number(words)
        if complex_result:
            return complex_result
        
        return text

# Test the fixed normalizer
normalizer = NumberNormalizer()

print("\n📝 Testing Final Number Normalization:")
print("-"*50)

test_cases = [
    ('दो', '2'),
    ('दस', '10'),
    ('पच्चीस', '25'),
    ('तीन सौ चौवन', '354'),
    ('एक सौ', '100'),
    ('पाँच सौ', '500'),
    ('एक हज़ार', '1000'),
    ('दो हज़ार तीन सौ', '2300'),
    ('पच्चीस हज़ार', '25000'),
    ('एक लाख', '100000'),
    ('दस लाख', '10000000'),  # This should now work
    ('एक करोड़', '10000000'),
    ('दस करोड़', '100000000'),
    ('दो-चार बातें', 'दो-चार बातें'),
    ('एक-दो दिन', 'एक-दो दिन'),
]

for test, expected in test_cases:
    result = normalizer.normalize(test)
    status = "✅" if result == expected else "❌"
    if result != expected:
        print(f"  Debug: {test} → {result} (expected: {expected})")
    else:
        print(f"{status} '{test}' → '{result}'")

# Test on actual data
print("\n" + "="*60)
print("Testing on actual raw ASR data:")
print("="*60)

df = pd.read_csv('raw_asr_output.csv')
df['normalized_numbers'] = df['raw_asr'].apply(normalizer.normalize)

# Find samples with numbers
print("\n✅ Final normalized output saved to raw_asr_normalized_final.csv")
df.to_csv('raw_asr_normalized_final.csv', index=False)

# Show examples with numbers
print("\n📝 Examples where numbers were found:")
count = 0
for idx, row in df.iterrows():
    if row['normalized_numbers'] != row['raw_asr']:
        print(f"\nSample {count+1}:")
        print(f"Original: {row['raw_asr'][:100]}...")
        print(f"Normalized: {row['normalized_numbers'][:100]}...")
        count += 1
        if count >= 5:
            break

if count == 0:
    print("No numbers found in raw ASR (raw ASR is very messy with repetition)")